// src/pages/signup.tsx
import React, { useMemo, useState } from "react";
import Header from "../components/Header"; // <- استيراد الهيدر (غيّر المسار لو لزم)

// بيانات المحافظات و المدن (تمثيلية)
const governorates = [
  "القاهرة", "الجيزة", "الإسكندرية", "بورسعيد", "الإسماعيلية", "السويس", "دمياط",
  "الدقهلية", "الشرقية", "الغربية", "المنوفية", "كفر الشيخ", "البحيرة", "مطروح",
  "الفيوم", "بني سويف", "المنيا", "قنا", "الأقصر", "أسوان", "سوهاج",
  "أسيوط", "قليوبية", "شمال سيناء", "جنوب سيناء", "البحر الأحمر"
];

const citiesMap: Record<string, string[]> = {
  "القاهرة": ["مدينة نصر", "المعادي", "التجمع الأول", "الزمالك", "شبرا", "حلوان"],
  "الجيزة": ["الدقي", "الهرم", "أكتوبر", "الجيزة", "المهندسين"],
  "الإسكندرية": ["محطة الرمل", "سموحة", "سيدي جابر", "العجمي", "برج العرب"],
  "الدقهلية": ["المنصورة", "ميت غمر", "طلخا", "أجا"],
  "الشرقية": ["الزقازيق", "بلبيس", "فاقوس", "العاشر من رمضان"],
  "الغربية": ["طنطا", "كفر الزيات", "المحلة الكبرى", "زفتى"],
  "المنوفية": ["شبين الكوم", "قويسنا", "بركة السبع"],
  "كفر الشيخ": ["كفر الشيخ", "دسوق", "مطوبس"],
  "البحيرة": ["دمنهور", "رشيد", "كوم حمادة"],
  "مطروح": ["مرسى مطروح", "الحمام"],
  "الفيوم": ["مدينة الفيوم", "إبشواي"],
  "بني سويف": ["بني سويف", "الواسطى"],
  "المنيا": ["المنيا", "مغاغة", "ملوي"],
  "قنا": ["قنا", "نجع حمادي"],
  "الأقصر": ["مدينة الأقصر", "القرنة"],
  "أسوان": ["أسوان", "نصر النوبة"],
  "سوهاج": ["سوهاج", "أخميم"],
  "أسيوط": ["أسيوط", "القوصية"],
  "قليوبية": ["بنها", "قها"],
  "بورسعيد": ["بورسعيد"],
  "الإسماعيلية": ["الإسماعيلية"],
  "السويس": ["السويس"],
  "دمياط": ["دمياط", "رأس البر"],
  "شمال سيناء": ["العريش"],
  "جنوب سيناء": ["شرم الشيخ"],
  "البحر الأحمر": ["الغردقة", "مرسى علم"]
};

const cssDelay = (ms: number): React.CSSProperties & Record<string, string> => {
  return ({ ["--delay"]: `${ms}ms` } as unknown) as React.CSSProperties & Record<string, string>;
};

const Signup: React.FC = () => {
  const [form, setForm] = useState({
    firstName: "",
    middleName: "",
    lastName: "",
    email: "",
    phone: "",
    nationalId: "",
    gender: "",
    grade: "",
    section: "",
    parentEmail: "",
    parentPhone: "",
    governorate: "",
    city: "",
    parentJob: "",
    password: "",
    confirmPassword: "",
  });

  const cities = useMemo(() => {
    if (!form.governorate) return [];
    return citiesMap[form.governorate] ?? [];
  }, [form.governorate]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    if (name === "governorate") {
      setForm((p) => ({ ...p, governorate: value, city: "" }));
    } else {
      setForm((p) => ({ ...p, [name]: value }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (form.password !== form.confirmPassword) {
      alert("كلمة المرور وتأكيدها غير متطابقين");
      return;
    }
    console.log("payload", form);
    alert("تم إرسال النموذج (مثال)");
  };

  return (
    <div>
      <Header />

      <div className="min-h-screen bg-black text-white py-12 px-4 sm:px-8 lg:px-20" dir="rtl">
        <style>{`
        @keyframes fadeIn { from { opacity: 0; transform: translateY(6px);} to { opacity:1; transform: translateY(0);} }
        .page-fade { animation: fadeIn 450ms cubic-bezier(.2,.9,.3,1) both; }
        @keyframes floaty { 0% { transform: translateY(0);} 50% { transform: translateY(-6px);} 100% { transform: translateY(0);} }
        .logo-float { animation: floaty 4s ease-in-out infinite; }
        @keyframes popIn { from { opacity: 0; transform: translateY(8px) scale(.995); } to { opacity: 1; transform: translateY(0) scale(1); } }
        .field { animation: popIn 420ms cubic-bezier(.22,.9,.3,1) both; animation-delay: var(--delay, 0ms); }
        .input-anim { transition: transform .18s ease, box-shadow .18s ease, border-color .18s ease; will-change: transform; }
        .input-anim:focus { transform: translateY(-4px); box-shadow: 0 10px 30px rgba(2,6,23,0.18); border-color: rgba(99,102,241,0.93); outline: none; }
        .cta-btn { transition: transform .18s ease, box-shadow .18s ease; } .cta-btn:hover { transform: translateY(-4px) scale(1.02); box-shadow: 0 20px 40px rgba(46, 115, 245, 0.18); }
        @media  ( max-width: 100px) { .name-row { flex-direction: column; align-items: flex-end; gap: 10px; } .name-row input { width: 100% !important; } }
      `}</style>

        <div className="max-w-6xl mx-auto page-fade">
          {/* =========================
            هنا استدعاء الـ Header (الـ navbar)
            ========================= */}

          <header className="text-center mb-8 logo-float">
            <h1 className="text-3xl md:text-4xl font-bold mb-2">إنشاء حساب الطالب</h1>
            <p className="text-gray-300">املأ بيانات الطالب وولي الأمر بدقة لتفعيل الحساب</p>
          </header>

          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-x-15 gap-y-6 text-right">
            <div className="ml-auto mr-auto md:col-span-2 flex name-row gap-8 items-end md:items-center  justify-end field" style={cssDelay(0)}>
              <div className="flex flex-col items-end w-full md:w-auto">
                <label className="mb-2 font-semibold text-base md:text-lg w-full text-right">الاسم الاول</label>
                <input name="firstName" value={form.firstName} onChange={handleChange} placeholder="الاسم الاول"
                  className="bg-gray-700 border border-gray-800 rounded-lg px-4 py-4 w-full md:w-72 text-white placeholder-gray-300 text-right focus:outline-none input-anim" />
              </div>

              <div className="flex flex-col items-end w-full md:w-auto">
                <label className="mb-2 font-semibold text-base md:text-lg w-full text-right">الثاني</label>
                <input name="middleName" value={form.middleName} onChange={handleChange} placeholder="الاسم الثاني"
                  className="bg-gray-700 border border-gray-800 rounded-lg px-4 py-4 w-full md:w-72 text-white placeholder-gray-300 text-right focus:outline-none input-anim" />
              </div>

              <div className="flex flex-col items-end w-full md:w-auto">
                <label className="mb-2 font-semibold text-base md:text-lg w-full text-right">الثالث</label>
                <input name="lastName" value={form.lastName} onChange={handleChange} placeholder="الاسم الثالث"
                  className="bg-gray-700 border border-gray-800 rounded-lg px-4 py-4 w-full md:w-72 text-white placeholder-gray-300 text-right focus:outline-none input-anim" />
              </div>
            </div>

            {/* باقي الحقول كما في ملفك الأصلي */}
            <div className="flex items-center justify-between field" style={cssDelay(80)}>
              <label className="font-semibold text-base md:text-lg">البريد الالكتروني</label>
              <input name="email" value={form.email} onChange={handleChange} placeholder="example@mail.com"
                className="bg-gray-700 border border-gray-800 rounded-lg px-4 py-3 w-full md:w-3/4 text-white placeholder-gray-300 input-anim" />
            </div>

            <div className="flex items-center justify-between field" style={cssDelay(150)}>
              <label className="font-semibold text-base md:text-lg">رقم الهاتف</label>
              <input name="phone" value={form.phone} onChange={handleChange} placeholder="01XXXXXXXXX"
                className="bg-gray-700 border border-gray-800 rounded-lg px-4 py-3 w-full md:w-3/4 text-white placeholder-gray-300 input-anim" />
            </div>

            <div className="flex items-center justify-between field" style={cssDelay(220)}>
              <label className="font-semibold text-base md:text-lg">الرقم القومي</label>
              <input name="nationalId" value={form.nationalId} onChange={handleChange} placeholder="الرقم القومي"
                className="bg-gray-700 border border-gray-800 rounded-lg px-4 py-3 w-full md:w-3/4 text-white placeholder-gray-300 input-anim" />
            </div>

            <div className="flex items-center justify-between field" style={cssDelay(290)}>
              <label className="font-semibold text-base md:text-lg">النوع</label>
              <select name="gender" value={form.gender} onChange={handleChange}
                className="bg-gray-700 border border-gray-800 rounded-lg mr-5 px-4 py-3 w-full md:w-3/4 text-white input-anim">
                <option value="">اختر النوع</option><option value="male">ذكر</option><option value="female">أنثى</option>
              </select>
            </div>

            <div className="flex items-center justify-between field" style={cssDelay(360)}>
              <label className=" font-semibold text-base md:text-lg">الصف</label>
              <select name="grade" value={form.grade} onChange={handleChange}
                className="mr-3 bg-gray-700 border border-gray-800 rounded-lg px-4 py-3 w-full md:w-3/4 text-white input-anim">
                <option value="">اختر الصف</option>
                <option value="3-prep">3 اعدادي</option>
                <option value="2-sec">2 ثانوي</option>
                <option value="3-sec">3 ثانوي</option>
              </select>
            </div>

            <div className="flex items-center justify-between field" style={cssDelay(430)}>
              <label className="font-semibold text-base md:text-lg">الشعبة</label>
              <select name="section" value={form.section} onChange={handleChange}
                className=" mr-2.5 bg-gray-700 border border-gray-800 rounded-lg px-4 py-3 w-full md:w-3/4 text-white input-anim">
                <option value="">اختر الشعبة</option>
                <option value="sci">علمي علوم</option>
                <option value="sci-math">علمي رياضة</option>
              </select>
            </div>

            <div className="flex items-center justify-between field" style={cssDelay(500)}>
              <label className="font-semibold text-base md:text-lg">البريد الإلكتروني لولي الأمر</label>
              <input name="parentEmail" value={form.parentEmail} onChange={handleChange} placeholder="parent@mail.com"
                className="bg-gray-700 border border-gray-800 rounded-lg px-4 py-3 w-full md:w-3/4 text-white placeholder-gray-300 input-anim" />
            </div>

            <div className="flex items-center justify-between field" style={cssDelay(570)}>
              <label className="font-semibold text-base md:text-lg">رقم هاتف ولي الأمر</label>
              <input name="parentPhone" value={form.parentPhone} onChange={handleChange} placeholder="01XXXXXXXXX"
                className="bg-gray-700 border border-gray-800 rounded-lg px-4 py-3 w-full md:w-3/4 text-white placeholder-gray-300 input-anim" />
            </div>

            <div className="flex items-center justify-between field" style={cssDelay(640)}>
              <label className="font-semibold text-base md:text-lg">المحافظة</label>
              <select name="governorate" value={form.governorate} onChange={handleChange}
                className="mr-3 bg-gray-700 border border-gray-800 rounded-lg px-4 py-3 w-full md:w-3/4 text-white input-anim">
                <option value="">اختر المحافظة</option>
                {governorates.map((g) => <option key={g} value={g}>{g}</option>)}
              </select>
            </div>

            <div className="flex items-center justify-between field" style={cssDelay(710)}>
              <label className="font-semibold text-base md:text-lg">المدينة / المركز</label>
              <select name="city" value={form.city} onChange={handleChange} disabled={!form.governorate}
                className="bg-gray-700 disabled:opacity-60 border border-gray-800 rounded-lg px-4 py-3 w-full md:w-3/4 text-white input-anim">
                <option value="">{form.governorate ? "اختر المدينة" : "اختر المحافظة أولاً"}</option>
                {cities.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>

            <div className="flex items-center justify-between field" style={cssDelay(780)}>
              <label className="font-semibold text-base md:text-lg">مهنة ولي الأمر</label>
              <input name="parentJob" value={form.parentJob} onChange={handleChange} placeholder="مهنة ولي الأمر"
                className="bg-gray-700 border border-gray-800 rounded-lg px-4 py-3 w-full md:w-3/4 text-white placeholder-gray-300 input-anim" />
            </div>

            <div className="flex items-center justify-between field" style={cssDelay(850)}>
              <label className="font-semibold text-base md:text-lg">الرقم السري</label>
              <input name="password" type="password" value={form.password} onChange={handleChange} placeholder="كلمة المرور"
                className="bg-gray-700 border border-gray-800 rounded-lg px-4 py-3 w-full md:w-3/4 text-white placeholder-gray-300 input-anim" />
            </div>

            <div className="flex items-center justify-between field" style={cssDelay(920)}>
              <label className="font-semibold text-base md:text-lg">تأكيد الرقم السري</label>
              <input name="confirmPassword" type="password" value={form.confirmPassword} onChange={handleChange} placeholder="تأكيد كلمة المرور"
                className="bg-gray-700 border border-gray-800 rounded-lg px-4 py-3 w-full md:w-3/4 text-white placeholder-gray-300 input-anim" />
            </div>

            <div className="md:col-span-2 mt-6 flex justify-center md:justify-end field" style={cssDelay(990)}>
              <button type="submit" className="px-8 py-4 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 rounded-full text-white font-semibold shadow-lg text-lg cta-btn">
                تسجيل
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>

  );
};

export default Signup;
