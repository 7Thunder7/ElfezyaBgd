// src/pages/LoginPage.tsx
import React from "react";
import { useNavigate } from "react-router-dom";
import LoginModal from "../components/LoginModal";

const LoginPage: React.FC = () => {
    const navigate = useNavigate();

    const handleClose = () => {
        // عند الإغلاق نرجع للصفحة الرئيسية (أو استخدم navigate(-1) للعودة)
        navigate("/", { replace: true });
    };

    return <LoginModal open={true} onClose={handleClose} />;
};

export default LoginPage;
