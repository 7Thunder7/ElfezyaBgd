import { useEffect, useMemo, useState } from "react";

/**
 * review.tsx
 * - يقرأ الفيديوهات والامتحانات من backend (Django)
 * - يعرض فيديوهات المراجعة (الأحدث أولاً)
 * - عند الضغط على فيديو يفتح مودال ويشغل الفيديو
 * - القسم الخاص بالامتحانات يعرض العناصر من الباك ويزداد تلقائياً عند إضافة امتحانات جديدة في الباك
 * - polling كل 10s لتحديث تلقائي (يمكن تعديله)
 *
 * Requirements from backend:
 * - GET /api/videos/ => [{ id, title, src, thumb, createdAt }, ...]
 * - GET /api/exams/  => [{ id, title, description, createdAt }, ...]
 *
 * إذا المسارات مختلفة غيّر الثوابت VIDEOS_API / EXAMS_API
 */

type VideoItem = {
    id: string;
    title: string;
    src: string;
    thumb?: string;
    createdAt: string;
};

type ExamItem = {
    id: string;
    title: string;
    description?: string;
    createdAt: string;
};

export default function ReviewPage() {
    // API endpoints (عدل حسب backend عندك)
    const VIDEOS_API = "/api/videos/";
    const EXAMS_API = "/api/exams/";

    // local state
    const [videos, setVideos] = useState<VideoItem[]>([]);
    const [exams, setExams] = useState<ExamItem[]>([]);
    const [loadingVideos, setLoadingVideos] = useState<boolean>(true);
    const [loadingExams, setLoadingExams] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);

    // slider & modal
    const [slideIndex, setSlideIndex] = useState(0);
    const [openVideo, setOpenVideo] = useState<VideoItem | null>(null);

    // fetch helpers
    const fetchVideos = async (signal?: AbortSignal) => {
        try {
            setLoadingVideos(true);
            setError(null);

            const res = await fetch(VIDEOS_API, { signal });
            if (!res.ok) throw new Error(`Videos API error ${res.status}`);

            const data = (await res.json()) as VideoItem[];
            setVideos(Array.isArray(data) ? data : []);
        } catch (err: unknown) {
            // إذا كان إلغاء الطلب (Abort) - نتعامل بأمان مع النوع unknown
            if (typeof DOMException !== "undefined" && err instanceof DOMException && err.name === "AbortError") {
                return;
            }
            if (typeof err === "object" && err !== null && "name" in err && (err as { name?: unknown }).name === "AbortError") {
                return;
            }

            // تحويل الرسالة لطريقة آمنة للعرض
            let msg = "حدث خطأ أثناء جلب الفيديوهات";
            if (err instanceof Error) msg = err.message;

            console.error("fetchVideos:", err);
            setError(msg);
        } finally {
            setLoadingVideos(false);
        }
    };

    const fetchExams = async (signal?: AbortSignal) => {
        try {
            setLoadingExams(true);
            setError(null);

            const res = await fetch(EXAMS_API, { signal });
            if (!res.ok) throw new Error(`Exams API error ${res.status}`);

            const data = (await res.json()) as ExamItem[];
            setExams(Array.isArray(data) ? data : []);
        } catch (err: unknown) {
            // تعامل آمن مع AbortError
            if (typeof DOMException !== "undefined" && err instanceof DOMException && err.name === "AbortError") {
                return;
            }
            if (typeof err === "object" && err !== null && "name" in err && (err as { name?: unknown }).name === "AbortError") {
                return;
            }

            let msg = "حدث خطأ أثناء جلب الامتحانات";
            if (err instanceof Error) msg = err.message;

            console.error("fetchExams:", err);
            setError(msg);
        } finally {
            setLoadingExams(false);
        }
    };

    // initial fetch + polling
    useEffect(() => {
        const controller = new AbortController();
        const doFetch = () => {
            fetchVideos(controller.signal);
            fetchExams(controller.signal);
        };

        doFetch(); // first fetch immediately

        // polling (every 10s) — يضمن ظهور إضافات الباك بدون إعادة تحميل الصفحة
        const POLL_MS = 10000;
        const timer = setInterval(doFetch, POLL_MS);

        return () => {
            controller.abort();
            clearInterval(timer);
        };

    }, []); // run once on mount

    // ensure newest show first
    const sortedVideos = useMemo(
        () => [...videos].sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt)),
        [videos]
    );

    // slider pagination helpers (simple page-based)
    const visiblePerView = 3;
    const pageCount = Math.max(1, Math.ceil(sortedVideos.length / visiblePerView));
    const lastIndex = Math.max(0, pageCount - 1);

    const nextSlide = () => setSlideIndex((s) => (s < lastIndex ? s + 1 : 0));
    const prevSlide = () => setSlideIndex((s) => (s > 0 ? s - 1 : lastIndex));

    const handleOpenVideo = (v: VideoItem) => setOpenVideo(v);
    const handleCloseModal = () => setOpenVideo(null);

    // small manual refresh (in case)
    const handleManualRefresh = async () => {
        setError(null);
        await Promise.all([fetchVideos(), fetchExams()]);
    };

    return (
        <div dir="rtl" className="min-h-screen bg-gradient-to-b from-neutral-900 via-slate-900 to-black text-white py-12 px-4 sm:px-8 lg:px-20">
            <style>{`
        @keyframes slideUpFade { from { transform: translateY(12px); opacity: 0 } to { transform: translateY(0); opacity: 1 } }
        .ani-pop { animation: slideUpFade .42s cubic-bezier(.2,.9,.3,1) both; }
        .bg-animated { background: linear-gradient(90deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01)); box-shadow: inset 0 0 120px rgba(255,255,255,0.01); transition: transform .45s ease; }
        .vid-card { transition: transform .3s cubic-bezier(.2,.9,.3,1), box-shadow .3s; }
        .vid-card:hover { transform: translateY(-8px) scale(1.01); box-shadow: 0 10px 30px rgba(2,6,23,0.6); }
        .modal-backdrop { background: rgba(2,6,23,0.6); backdrop-filter: blur(4px); }
        @media (max-width: 640px) { .video-slide { min-width: 85% !important; } }
      `}</style>

            <header className="mb-8 text-center ani-pop">
                <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight">المراجعة — يلا بينا نراجع</h1>
                <p className="mt-2 text-gray-300">الفيديوهات والامتحانات تُحمّل من السيرفر. أية إضافة بالباك تظهر تلقائياً بالواجهة.</p>
            </header>

            {error && (
                <div className="mb-6 max-w-3xl mx-auto text-center">
                    <div className="inline-block px-4 py-2 bg-red-600 text-white rounded-md">{error}</div>
                    <button onClick={handleManualRefresh} className="mx-3 px-3 py-1 bg-white/6 rounded-md">حاول مرة أخرى</button>
                </div>
            )}

            {/* Videos slider */}
            <section className="mb-12 ani-pop">
                <div className="flex items-center justify-between mb-4">
                    <h2 className="text-lg font-semibold">فيديوهات المراجعة</h2>
                    <div className="flex items-center gap-3">
                        <button onClick={prevSlide} className="w-9 h-9 rounded-md bg-white/6 hover:bg-white/10">‹</button>
                        <button onClick={nextSlide} className="w-9 h-9 rounded-md bg-white/6 hover:bg-white/10">›</button>
                        <button onClick={handleManualRefresh} className="px-3 py-1 rounded-md bg-white/6 hover:bg-white/10 text-sm">تحديث</button>
                    </div>
                </div>

                <div className="bg-animated rounded-xl p-4">
                    {loadingVideos && <div className="text-sm text-gray-400 mb-2">جاري جلب الفيديوهات…</div>}

                    <div className="overflow-hidden">
                        <div
                            className="flex gap-4 transition-transform duration-500"
                            style={{
                                transform: `translateX(-${slideIndex * 100}%)`,
                                width: `${pageCount * 100}%`,
                            }}
                        >
                            {sortedVideos.length === 0 && !loadingVideos ? (
                                <div className="p-8 text-center text-gray-400">لا توجد فيديوهات حالياً.</div>
                            ) : (
                                // each card width is fraction: we make wrapper width flexible and each child min-width so transform works as pages
                                sortedVideos.map((v) => (
                                    <div
                                        key={v.id}
                                        className="video-slide vid-card min-w-[30%] sm:min-w-[28%] md:min-w-[22%] rounded-lg overflow-hidden bg-white/5 p-3"
                                        style={{ backdropFilter: "blur(6px)" }}
                                    >
                                        <div className="relative cursor-pointer" onClick={() => handleOpenVideo(v)}>
                                            <img src={v.thumb ?? "https://picsum.photos/seed/video/400/240"} alt={v.title} className="w-full h-40 object-cover rounded-md" />
                                            <div className="absolute inset-0 flex items-center justify-center">
                                                <div className="w-12 h-12 rounded-full bg-black/40 flex items-center justify-center text-white text-2xl">▶</div>
                                            </div>
                                        </div>

                                        <div className="mt-3">
                                            <h4 className="text-sm font-semibold">{v.title}</h4>
                                            <div className="mt-2 text-xs text-gray-400">أضيف في: {new Date(v.createdAt).toLocaleDateString()}</div>
                                            <div className="mt-2 text-xs text-gray-300 line-clamp-2">{v.src}</div>
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>

                    <div className="mt-3 text-xs text-gray-400">اضغط على الصورة لتشغيل الفيديو داخل الصفحة. الفيديوهات المضافة حديثًا تظهر أولاً.</div>
                </div>
            </section>

            {/* Exams section */}
            <section className="mb-12 ani-pop">
                <div className="flex items-center justify-between mb-4">
                    <h2 className="text-lg font-semibold">قسم الامتحانات</h2>
                    <div className="text-xs text-gray-400">الامتحانات تُدار من لوحة الإدارة في السيرفر</div>
                </div>

                {loadingExams ? (
                    <div className="text-sm text-gray-400">جاري جلب الامتحانات…</div>
                ) : exams.length === 0 ? (
                    <div className="text-gray-400">لا توجد امتحانات حالياً.</div>
                ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        {exams.map((ex) => (
                            <article key={ex.id} className="bg-white/5 rounded-xl p-4 shadow-sm hover:shadow-lg transition-transform transform hover:-translate-y-2">
                                <div className="flex items-start gap-3">
                                    <div className="flex-none w-12 h-12 rounded-md bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center font-bold text-black">
                                        {ex.title.split(" ").slice(0, 2).map((w) => w[0]).join("")}
                                    </div>

                                    <div className="flex-grow">
                                        <h3 className="font-semibold">{ex.title}</h3>
                                        <p className="text-sm text-gray-300 mt-1">{ex.description}</p>

                                        <div className="mt-3 flex items-center gap-3">
                                            <button className="px-3 py-1 rounded-md bg-blue-600 text-white text-sm hover:bg-blue-700">ابدأ الامتحان</button>
                                            <div className="text-xs text-gray-400 ml-auto">{new Date(ex.createdAt).toLocaleDateString()}</div>
                                        </div>
                                    </div>
                                </div>
                            </article>
                        ))}
                    </div>
                )}
                <div className="mt-4 text-xs text-gray-400">كل ما تضيف امتحان جديد من السيرفر سيظهر هنا تلقائياً (وبدون تعديل على الواجهة).</div>
            </section>

            {/* Video modal */}
            {openVideo && (
                <div className="fixed inset-0 z-50 flex items-center justify-center modal-backdrop" role="dialog" aria-modal="true" onClick={handleCloseModal}>
                    <div className="max-w-3xl w-full mx-4" onClick={(e) => e.stopPropagation()}>
                        <div className="bg-white/6 rounded-xl overflow-hidden shadow-xl">
                            <div className="flex items-center justify-between p-3 border-b border-white/6">
                                <h3 className="font-semibold">{openVideo.title}</h3>
                                <button onClick={handleCloseModal} className="px-3 py-1 rounded-md bg-white/6">إغلاق</button>
                            </div>
                            <div className="p-4 bg-black">
                                <video controls className="w-full h-[60vh] max-h-[70vh] bg-black rounded">
                                    <source src={openVideo.src} />
                                    المتصفح الخاص بك لا يدعم عنصر الفيديو.
                                </video>
                            </div>
                            <div className="p-4 flex items-center gap-3">
                                <div className="text-sm text-gray-300">تمت إضافة الفيديو: {new Date(openVideo.createdAt).toLocaleString()}</div>
                                <div className="ml-auto text-xs text-gray-400">اضغط خارج المربع لإغلاق</div>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            <footer className="mt-10 text-center text-sm text-gray-400">بالتوفيق — مراجعات سريعة ومريحة ✨</footer>
        </div>
    );
}
