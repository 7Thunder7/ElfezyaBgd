import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

/**
 * learning.tsx (v2) - معدل لحل مشاكل TypeScript المتعلقة بأنواع part/step
 * - صفحة التعلم مقسمة جزئين (الجزء الأول + الجزء الثاني)
 * - كل جزء يحتوي على 4 مستطيلات (شرح، كويز سريع، فيديو حل، امتحان)
 * - الجزء الثاني مغلق بالكامل لحد ما يكمّل الطالب الجزء الأول
 * - كل عنصر يُفتح تدريجياً؛ عند إكمال كل خطوة يظهر ✅ ويفتح التالي
 * - يخزن التقدم في localStorage تحت المفتاح LEARNING_V2_PROGRESS
 */

type StepState = {
    watched: boolean;
    unlocked: boolean;
};

type PartProgress = {
    step1: StepState; // شرح
    step2: StepState; // كويز سريع
    step3: StepState; // فيديو حلول
    step4: StepState; // امتحان
};

type Progress = {
    part1: PartProgress;
    part2: PartProgress;
};

const STORAGE_KEY = "LEARNING_V2_PROGRESS";

const DEFAULT_PART: PartProgress = {
    step1: { watched: false, unlocked: true },
    step2: { watched: false, unlocked: false },
    step3: { watched: false, unlocked: false },
    step4: { watched: false, unlocked: false },
};

function readProgress(): Progress {
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (!raw)
            return {
                part1: DEFAULT_PART,
                part2: { ...DEFAULT_PART, step1: { watched: false, unlocked: false } },
            };
        return JSON.parse(raw) as Progress;
    } catch {
        return {
            part1: DEFAULT_PART,
            part2: { ...DEFAULT_PART, step1: { watched: false, unlocked: false } },
        };
    }
}

function writeProgress(p: Progress) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(p));
}

export default function LearningPageV2() {
    const navigate = useNavigate();
    const [progress, setProgress] = useState<Progress>(readProgress());

    // UI state for inline video modals
    // ضيّقنا الأنواع هنا حتى تتطابق مع توقيع setStep
    const [activeVideo, setActiveVideo] = useState<{ part: 1 | 2; step: 1 | 2 | 3 | 4 } | null>(null);

    useEffect(() => {
        writeProgress(progress);
    }, [progress]);

    // helper to update a specific part/step
    const setStep = (part: 1 | 2, stepKey: keyof PartProgress, next: Partial<StepState>) => {
        setProgress((prev) => {
            const partKey = part === 1 ? "part1" : "part2";
            const p = { ...prev };
            p[partKey] = { ...p[partKey], [stepKey]: { ...p[partKey][stepKey], ...next } };

            // After marking watched=true, automatically unlock the following step in the same part
            if (next.watched === true) {
                const order: (keyof PartProgress)[] = ["step1", "step2", "step3", "step4"];
                const idx = order.indexOf(stepKey);
                if (idx >= 0 && idx < order.length - 1) {
                    const nextStep = order[idx + 1];
                    p[partKey][nextStep] = { ...p[partKey][nextStep], unlocked: true };
                }
            }

            return p;
        });
    };

    // When a whole part is completed, unlock part2 (first step) if part1 complete
    useEffect(() => {
        const p1 = progress.part1;
        const allDone1 = Object.values(p1).every((s) => s.watched === true);
        if (allDone1) {
            setProgress((prev) => ({
                ...prev,
                part2: { ...prev.part2, step1: { ...prev.part2.step1, unlocked: true } },
            }));
        }
    }, [progress.part1]);

    const resetProgress = () => {
        const fresh: Progress = {
            part1: DEFAULT_PART,
            part2: { ...DEFAULT_PART, step1: { watched: false, unlocked: false } },
        };
        setProgress(fresh);
        writeProgress(fresh);
    };

    // rendering helper for a single card
    const Card: React.FC<{
        title: string;
        subtitle?: string;
        part: 1 | 2;
        stepKey: keyof PartProgress;
        onOpen?: () => void;
        onAction?: () => void; // used for quiz navigation
    }> = ({ title, subtitle, part, stepKey, onOpen, onAction }) => {
        const partKey = part === 1 ? "part1" : "part2";
        const state = (progress)[partKey][stepKey] as StepState;

        const isUnlocked = state.unlocked;
        const isDone = state.watched;

        return (
            <div
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                    if (e.key === "Enter" && isUnlocked) {
                        if (onOpen) onOpen();
                    }
                }}
                onClick={() => {
                    if (!isUnlocked) return;
                    if (onOpen) onOpen();
                }}
                className={`card-glass transform transition-transform duration-300 hover:scale-105 ${isUnlocked ? "cursor-pointer" : "opacity-60 pointer-events-none"}`}
                style={{ minHeight: 140 }}
            >
                <div className="flex items-start justify-between">
                    <div>
                        <h4 className="text-lg font-semibold">{title}</h4>
                        {subtitle && <p className="text-sm text-gray-300 mt-1">{subtitle}</p>}
                    </div>

                    <div className="flex items-center gap-2">
                        {isDone ? (
                            <div className="text-green-400 text-xl" aria-hidden>
                                ✅
                            </div>
                        ) : (
                            <div className="text-gray-400 text-xl">◻️</div>
                        )}
                    </div>
                </div>

                <div className="mt-4 flex items-center gap-3">
                    {/* Action buttons */}
                    {onAction ? (
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                if (!isUnlocked) return;
                                onAction();
                            }}
                            className={`btn-primary-gradient inline-flex items-center gap-2 ${isUnlocked ? "" : "opacity-60"}`}
                        >
                            افتح
                        </button>
                    ) : (
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                if (!isUnlocked) return;
                                if (onOpen) onOpen();
                            }}
                            className={`px-3 py-1 rounded-md border ${isUnlocked ? "border-transparent" : "border-white/10"}`}
                        >
                            افتح
                        </button>
                    )}

                    {/* Quick hint */}
                    <div className="text-sm text-gray-300">{isUnlocked ? "مفتوح" : "مقفول"}</div>
                </div>
            </div>
        );
    };

    // local typed alias to help TypeScript narrow inside JSX branch
    const active = activeVideo as { part: 1 | 2; step: 1 | 2 | 3 | 4 } | null;

    return (
        <div dir="rtl" className="min-h-screen bg-gradient-to-b from-neutral-900 via-slate-900 to-black text-white py-12 px-4 sm:px-8 lg:px-20">
            <div className="max-w-6xl mx-auto space-y-6">
                <header className="text-center">
                    <h1 className="text-3xl font-extrabold">صفحة التعلم — الدرس</h1>
                    <p className="mt-2 text-gray-300">اشتغل على المحتوى بالترتيب؛ الجزء الثاني سيُفتح بعد إكمال الجزء الأول.</p>
                </header>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Part 1 container */}
                    <section className="space-y-4">
                        <div className="flex items-center justify-between">
                            <h2 className="text-xl font-bold">الجزء الأول</h2>
                            <div className="text-sm text-gray-300">تقدم: {Object.values(progress.part1).filter((s) => s.watched).length}/4</div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <Card
                                title="شرح الجزء الأول"
                                subtitle="شاهد الفيديو التعليمي"
                                part={1}
                                stepKey="step1"
                                onOpen={() => setActiveVideo({ part: 1, step: 1 })}
                            />

                            <Card
                                title="كويز على السريع"
                                subtitle="اختبار قصير لقياس الفهم"
                                part={1}
                                stepKey="step2"
                                onAction={() => navigate("/quick-quiz?part=1")}
                                onOpen={() => navigate("/quick-quiz?part=1")}
                            />

                            <Card
                                title="فيديو حل أسئلة الكتاب"
                                subtitle="شاهد شرح الحلول بعد الاجابة"
                                part={1}
                                stepKey="step3"
                                onOpen={() => setActiveVideo({ part: 1, step: 3 })}
                            />

                            <Card
                                title="امتحان على الجزء"
                                subtitle="امتحان شامل على الجزء الأول"
                                part={1}
                                stepKey="step4"
                                onAction={() => navigate("/final-quiz?part=1")}
                                onOpen={() => navigate("/final-quiz?part=1")}
                            />
                        </div>
                    </section>

                    {/* Part 2 container */}
                    <section className={`space-y-4 ${Object.values(progress.part1).every((s) => s.watched) ? "" : "opacity-80"}`}>
                        <div className="flex items-center justify-between">
                            <h2 className="text-xl font-bold">الجزء الثاني</h2>
                            <div className="text-sm text-gray-300">تقدم: {Object.values(progress.part2).filter((s) => s.watched).length}/4</div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <Card
                                title="شرح الجزء الثاني"
                                subtitle="شاهد الفيديو التعليمي"
                                part={2}
                                stepKey="step1"
                                onOpen={() => setActiveVideo({ part: 2, step: 1 })}
                            />

                            <Card
                                title="كويز على السريع"
                                subtitle="اختبار قصير لقياس الفهم"
                                part={2}
                                stepKey="step2"
                                onAction={() => navigate("/quick-quiz?part=2")}
                                onOpen={() => navigate("/quick-quiz?part=2")}
                            />

                            <Card
                                title="فيديو حل أسئلة الكتاب"
                                subtitle="شاهد شرح الحلول بعد الاجابة"
                                part={2}
                                stepKey="step3"
                                onOpen={() => setActiveVideo({ part: 2, step: 3 })}
                            />

                            <Card
                                title="امتحان على الجزء"
                                subtitle="امتحان شامل على الجزء الثاني"
                                part={2}
                                stepKey="step4"
                                onAction={() => navigate("/final-quiz?part=2")}
                                onOpen={() => navigate("/final-quiz?part=2")}
                            />
                        </div>
                    </section>
                </div>

                <div className="flex items-center justify-between">
                    <button className="px-3 py-2 rounded-md border border-white/10 text-sm text-gray-200 hover:bg-white/5" onClick={resetProgress}>
                        إعادة ضبط التقدم
                    </button>

                    <div className="text-sm text-gray-300">ملاحظة : التقدم يُحفظ تلقائياً .</div>
                </div>

                {/* Inline video area (متحكم به عن طريق activeVideo) */}
                {active && (
                    <div className="mt-6 card-glass">
                        <div className="flex items-center justify-between">
                            <h3 className="text-lg font-semibold">مشغل الفيديو — جزء {active.part} — خطوة {active.step}</h3>
                            <button
                                className="px-3 py-1 rounded-md border border-white/10"
                                onClick={() => setActiveVideo(null)}
                            >
                                إغلاق
                            </button>
                        </div>

                        <div className="mt-4">
                            <video
                                controls
                                onEnded={() => {
                                    // علامة انتهاء الفيديو: علم عليه كمشاهدة
                                    setStep(active.part, (`step${active.step}` as keyof PartProgress), { watched: true });
                                    setActiveVideo(null);
                                }}
                                style={{ width: "100%", maxHeight: 520 }}
                            >
                                {/* استبدل مسارات الفيديو بالمحتوى الحقيقي عندك */}
                                <source src={`/videos/part${active.part}-step${active.step}.mp4`} type="video/mp4" />
                                المتصفح لا يدعم تشغيل الفيديو.
                            </video>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}
