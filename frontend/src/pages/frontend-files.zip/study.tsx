// src/pages/study.tsx
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom"; // مضافة لاستخدام التنقّل للمراجعة

/**
 * صفحة Study
 * - تعمل الآن باستخدام بيانات Mock (عشان الـ backend مش متوصل بعد)
 * - كود الجلب من الـ API موجود معلق (commented) تحت قسم "UNCOMMENT TO ENABLE API"
 * - تعليقات بالعربية تشرح إزاي تفك التعليقات وقت ما تكون جاهز
 */

/* ---------- Types ---------- */
type Item = {
    id: string;
    title: string;
    img?: string;
    description?: string;
};

type Section = {
    id: string;
    title: string;
    items: Item[];
};

/* ---------- Mock data (تأكد إنك تحذفها أو خليها للاحتياط بعد ما تشتغل من الـ backend) ---------- */
const MOCK_SECTIONS: Section[] = [
    {
        id: "core",
        title: " الوحدة الاولي",
        items: [
            { id: "phy1", title: "الميكانيكا 1", img: "/src/imgs/placeholder.png", description: "مقدمة في الحركة و القوانين الأساسية" },
            { id: "phy2", title: "الكهرباء الساكنة", img: "/src/imgs/placeholder.png", description: "شحنة، مجال و فرق جهد" },
            { id: "phy3", title: "الاهتزازات", img: "/src/imgs/placeholder.png", description: "الاهتزازات البسيطة والموجات" },
        ],
    },
    {
        id: "adv",
        title: "الوحدة الثانية ",
        items: [
            { id: "elec1", title: "دوائر كهربية", img: "/src/imgs/placeholder.png", description: "تحليل الدوائر المستمرة" },
            { id: "thermo", title: "الحرارة و الديناميكا", img: "/src/imgs/placeholder.png", description: "قوانين الديناميكا الحرارية" },
            { id: "optics", title: "البصريات", img: "/src/imgs/placeholder.png", description: "العدسات، المرايا، والتداخل" },
        ],
    },
    {
        id: "calc",
        title: "التمارين و الاختبارات",
        items: [
            { id: "quiz1", title: "اختبار سريع - ترم 1", img: "/src/imgs/placeholder.png", description: "اختبار تشخيصي لمدة 15 دقيقة" },
            { id: "ex1", title: "حلول مسائل", img: "/src/imgs/placeholder.png", description: "حلول مرفقة بالشرح خطوة بخطوة" },
        ],
    },
];

const Study: React.FC = () => {
    const navigate = useNavigate(); // استخدمناه للمستطيل الجديد
    // لاحظ: استعملنا mockSections كقيمة مبدئية عشان الصفحة تشتغل بدون backend
    const [sections, setSections] = useState<Section[] | null>(MOCK_SECTIONS);
    const [loading, setLoading] = useState<boolean>(false); // false لأننا نستخدم mock افتراضاً
    const [error, setError] = useState<string | null>(null);

    // openMap لتتبع الأقسام المفتوحة (accordion)
    const [openMap, setOpenMap] = useState<Record<string, boolean>>(() => {
        const map: Record<string, boolean> = {};
        MOCK_SECTIONS.forEach((s) => (map[s.id] = false));
        return map;
    });

    const toggle = (id: string) => {
        setOpenMap((prev) => ({ ...prev, [id]: !prev[id] }));
    };

    /* -----------------------------
       UNCOMMENT TO ENABLE API FETCH
       ------------------------------------------------
       بعد ما تجهز الـ backend و endpoint (مثال: /api/sections/)
       - افك الكود اللي تحت (إزالة التعليقات)
       - غيّر الـ URL لو لازم
       - ممكن تترك MOCK_SECTIONS للـ fallback لو فشل الاتصال

       ملاحظة مهمة: استخدمت نوع 'unknown' في catch — لو فكيت التعليقات اتبع طريقة التحويل الموجودة أدناه.
    ------------------------------ */


    useEffect(() => {
        let mounted = true;
        (async () => {
            if (!mounted) return;
            setLoading(true);
            setError(null);
            try {
                const res = await fetch("/api/sections/"); // <-- غير الـ URL لو backend عندك مختلف
                if (!res.ok) throw new Error(`HTTP ${res.status}`);
                const data: Section[] = await res.json();
                if (mounted) {
                    setSections(data);
                    // بناء خريطة الفتح حسب الأقسام الراجعة
                    const defaultMap: Record<string, boolean> = {};
                    data.forEach((s) => (defaultMap[s.id] = false));
                    setOpenMap(defaultMap);
                }
            } catch (err: unknown) {
                // تحويل err بأمان دون استخدام `any`
                let msg = "حدث خطأ أثناء جلب البيانات";
                if (err instanceof Error) {
                    msg = err.message;
                } else if (typeof err === "string") {
                    msg = err;
                } else {
                    // للـ dev: console.error("fetch error:", err);
                }
                if (mounted) setError(msg);
            } finally {
                if (mounted) setLoading(false);
            }
        })();

        return () => {
            mounted = false;
        };
    }, []);


    /* -----------------------------
       END OF API FETCH SECTION
       ------------------------------ */

    // Rendering states
    if (loading)
        return (
            <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-neutral-900 via-slate-900 to-black text-white">
                <div className="text-center">
                    <div className="mb-4 animate-pulse">جاري التحميل...</div>
                    <div className="text-sm text-gray-400">انتظر قليلاً — يتم جلب المحتوى</div>
                </div>
            </div>
        );

    if (error)
        return (
            <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-neutral-900 via-slate-900 to-black text-white px-4">
                <div className="max-w-xl text-center">
                    <h2 className="text-2xl font-semibold mb-2">حدث خطأ</h2>
                    <p className="text-gray-300 mb-4">{error}</p>
                    <button
                        onClick={() => {
                            // موقت: إعادة تحميل الصفحة أو يمكنك إنك تفك تعليق الـ fetch لتجربة إعادة المحاولة
                            window.location.reload();
                        }}
                        className="px-4 py-2 bg-blue-600 rounded-md text-white hover:bg-blue-700"
                    >
                        إعادة المحاولة
                    </button>
                </div>
            </div>
        );

    // Main UI
    return (
        <div dir="rtl" className="min-h-screen bg-gradient-to-b from-neutral-900 via-slate-900 to-black text-white py-12 px-4 sm:px-8 lg:px-20">
            <div className="max-w-6xl mx-auto">
                <header className="mb-8 text-center">
                    <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight">مكتبة الدراسة</h1>
                    <p className="mt-2 text-gray-300">اختار الوحدةالي حابب تذارها — اختار الدرس وشوف المحتوي </p>
                </header>

                {/* ====== المستطيل الإضافي للمراجعة (طلبك) ======
                    مظهره مطابق للطابع العام: شفافية، ظل، hover effect.
                    عند الضغط ينتقل للمسار /review
                */}
                <div
                    role="button"
                    tabIndex={0}
                    onClick={() => navigate("/review")}
                    onKeyDown={(e) => {
                        if (e.key === "Enter") navigate("/review");
                    }}
                    className="mb-6 card-glass p-4 flex items-center justify-between cursor-pointer hover:shadow-md transform transition-transform duration-200 hover:-translate-y-1"
                    aria-label="اذهب إلى صفحة المراجعة"
                >
                    <div>
                        <h3 className="text-lg font-semibold"> قسم المراجعة </h3>
                        <p className="text-sm text-gray-300 mt-1">راجع أهم النقاط في الدروس السابقة — اضغط للذهاب إلى صفحة المراجعة.</p>
                    </div>

                    <div className="flex items-center gap-3">
                        <span className="text-sm text-gray-300">اذهب</span>
                        <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden>
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                        </svg>
                    </div>
                </div>

                <div className="space-y-4">
                    {(sections ?? []).map((sec, idx) => {
                        const isOpen = !!openMap[sec.id];
                        return (
                            <section key={sec.id} className="bg-white/5 rounded-xl shadow-sm overflow-hidden">
                                <button
                                    onClick={() => toggle(sec.id)}
                                    aria-expanded={isOpen}
                                    aria-controls={`panel-${sec.id}`}
                                    className="w-full flex items-center justify-between gap-4 py-4 px-4 sm:px-6 cursor-pointer hover:bg-white/3 transition-colors"
                                >
                                    <div className="flex items-center gap-4">
                                        <div className="flex-none">
                                            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-indigo-500 flex items-center justify-center shadow-md transform transition-transform duration-300 hover:scale-105">
                                                <span className="text-lg font-bold">{idx + 1}</span>
                                            </div>
                                        </div>

                                        <div>
                                            <h3 className="text-lg sm:text-xl font-semibold">{sec.title}</h3>
                                            <p className="text-sm text-gray-400 mt-1">{sec.items.length} عنصر</p>
                                        </div>
                                    </div>

                                    <div className={`flex-none transition-transform duration-300 ${isOpen ? "rotate-90" : "rotate-0"} text-gray-300`}>
                                        <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                                        </svg>
                                    </div>
                                </button>

                                <div
                                    id={`panel-${sec.id}`}
                                    className={`px-4 sm:px-6 transition-[max-height,opacity] duration-500 ease-[cubic-bezier(.2,.9,.3,1)] overflow-hidden ${isOpen ? "max-h-[1200px] opacity-100 py-6" : "max-h-0 opacity-0 py-0"}`}
                                >
                                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                                        {sec.items.map((it) => (
                                            <article
                                                key={it.id}
                                                className="flex items-center gap-4 bg-white/5 rounded-lg p-3 hover:shadow-lg transition-shadow transform hover:-translate-y-1"
                                                role="article"
                                                style={{ backdropFilter: "blur(6px)" }}
                                            >
                                                <div className="flex-none w-28 h-20 rounded-lg overflow-hidden">
                                                    <img src={it.img ?? "/src/imgs/placeholder.png"} alt={it.title} className="w-full h-full object-cover" />
                                                </div>

                                                <div className="grow">
                                                    <h4 className="text-base sm:text-lg font-semibold">{it.title}</h4>
                                                    <p className="text-sm text-gray-300 mt-1 line-clamp-2">{it.description ?? "وصف مختصر للمادة أو الدرس إن احتجت تضيفه لاحقاً"}</p>

                                                    <div className="mt-3 flex items-center gap-2">
                                                        <button
                                                            onClick={() =>
                                                                // مشاهدة: افتح صفحة التعلم للدرس واضع طلب تشغيل الجزء الأول
                                                                navigate(`/learning/${it.id}`, {
                                                                    state: { playFirst: true, lessonId: it.id },
                                                                })
                                                            }
                                                            className="px-3 py-1 rounded-md bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-sm shadow-sm hover:brightness-110 transition"
                                                        >
                                                            مشاهدة
                                                        </button>
                                                        <button
                                                            onClick={() =>
                                                                // اطلع: افتح صفحة Learning الخاصة بالدرس الذي ضغط عليه (بدون تشغيل تلقائي)
                                                                navigate(`/learning/${it.id}`, {
                                                                    state: { lessonId: it.id },
                                                                })
                                                            }
                                                            className="px-3 py-1 rounded-md border border-white/10 text-sm text-gray-200 hover:bg-white/5 transition"
                                                        >
                                                            اطلع
                                                        </button>
                                                    </div>
                                                </div>
                                            </article>
                                        ))}
                                    </div>
                                </div>
                            </section>
                        );
                    })}
                </div>

                <footer className="mt-10 text-center text-sm text-gray-400">
                    استمتع بتعلمك معنا
                </footer>
            </div>

            <style>{`
        .line-clamp-2 {
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;  
          overflow: hidden;
        }

        @media (prefers-reduced-motion: no-preference) {
          .transition-[max-height,opacity] {
            /* توضيح فقط: الانتقال يتم عبر tailwind utility */
          }
        }

        @media (max-width: 420px) {
          .grid-cols-1.sm\\:grid-cols-2 {
            grid-template-columns: repeat(1, minmax(0, 1fr));
          }
          article { padding: 12px; }
        }
      `}</style>
        </div>
    );
};

export default Study;
